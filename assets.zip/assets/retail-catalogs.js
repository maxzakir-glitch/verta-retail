/* Добавляйте только согласованные модели. Пустые размеры/материалы не выдумываются. */
window.VERTA_RETAIL_CATALOGS = {
  "bakery": [
    {
      "name": "Хлебный стеллаж",
      "image": "assets/images/item-09.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    },
    {
      "name": "Островная хлебная витрина",
      "image": "assets/images/item-10.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    }
  ],
  "grocery": [
    {
      "name": "Стеллаж для кондитерских товаров",
      "image": "assets/images/item-16.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    },
    {
      "name": "Пристенный стеллаж для бакалеи",
      "image": "assets/images/item-14.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    }
  ],
  "cafe": [
    {
      "name": "Столы",
      "image": "assets/images/cafe-tables.webp",
      "dimensions": null,
      "material": null,
      "note": "Пример со страницы VERTA «Мебель для ресторанов»"
    },
    {
      "name": "Кашпо",
      "image": null,
      "dimensions": null,
      "material": null,
      "note": ""
    },
    {
      "name": "Ограждения",
      "image": null,
      "dimensions": null,
      "material": null,
      "note": ""
    },
    {
      "name": "Тумбы для рамен",
      "image": null,
      "dimensions": null,
      "material": null,
      "note": ""
    },
    {
      "name": "Барные стойки",
      "image": "assets/images/cafe-counter.webp",
      "dimensions": null,
      "material": null,
      "note": "Пример со страницы VERTA «Мебель для ресторанов»"
    },
    {
      "name": "Облицовка рабочих зон пищевого производства",
      "image": null,
      "dimensions": null,
      "material": null,
      "note": ""
    }
  ],
  "coffee": [],
  "drinks": [
    {
      "name": "Стеллаж для напитков",
      "image": "assets/images/item-00.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    }
  ],
  "vegetables": [],
  "shelving": [
    {
      "name": "Островной торговый стеллаж",
      "image": "assets/images/item-20.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    },
    {
      "name": "Радиальная промостойка",
      "image": "assets/images/item-17.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    },
    {
      "name": "Модуль акцентной выкладки",
      "image": "assets/images/item-18.webp",
      "dimensions": null,
      "material": null,
      "note": "Фото из проекта VERTA"
    }
  ],
  "interior": [],
  "shop-in-shop": []
};
